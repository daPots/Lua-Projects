PowerBall = Class{}

function PowerBall:init()
    self.x = math.random(15, VIRTUAL_WIDTH - 15)
    self.y = math.random(((VIRTUAL_HEIGHT / 2) * .75), VIRTUAL_HEIGHT - 50)
    self.dy = 0
    self.width = 16
    self.height = 16
    self.inPlay = true
end

function PowerBall:hit()
    gSounds['extra-balls']:stop()
    gSounds['extra-balls']:play()
    self.inPlay = false
end

function PowerBall:render()
    if self.inPlay then
        love.graphics.draw(gTextures['main'], gFrames['extra-balls'],  self.x, self.y)
    end
end